"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""

p = float(input("Enter the principal amount:"))
r = float(input("Enter the annual interest rate:"))
t = float(input("Enter the number of years the deposit is borrowed for:"))
n = float(input("Enter the number of times the interest is compounded per year:"))

a = (p * ((1 + (r / n)) ** (n * t)))  # formula to calculate interest

print("Balance: $ {:.2f}".format(a))  # prints balance and formats to two decimal places

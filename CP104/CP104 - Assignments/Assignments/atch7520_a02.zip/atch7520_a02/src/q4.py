"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""

# date originally entered in the mmddyyyy format
original = int(input("Enter date: "))

# get the first two digits mathematically
month = original / 1000000

# remove the decimals without using round()
month = int(month)

# temp variable with the format ddyyyy
temp = original - (month * 1000000)  # removing the first two digits mathematically

day = temp // 10000  # using integer division to remove the yyyy and get the date

# getting the year by mathematically removing the dd digits
year = temp - (day * 10000)

# final formatted print statement
print("{:2.0f}/{:2.0f}/{:4.0f}".format(day, month, year))


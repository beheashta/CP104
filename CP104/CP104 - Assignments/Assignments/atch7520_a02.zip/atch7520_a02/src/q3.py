"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""
sales = float(input("Enter the total amount of sales:"))

# the annual profit percentage
annualProfit = (0.23) 

# the actual number percentage, used later for print statement
percentage = (annualProfit * 100) 

# calculating the end profit with sales
profit = ((1 + annualProfit) * sales)

# report variable for ease of printing and formatting
report = ('''
 Projected Profit Report
--------------------------
 Total sales: $ {:9.2f}
 Annual profit: % {:.0f} 
--------------------------
 Profit: $ {:8.2f}
'''.format(sales, percentage, profit))

# final print statement
print(report)

"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-09-19"
------------------------------------------------------------------------
"""

first = input("What is your first name?:")
last = input("What is your last name?:")

print("Welcome {} {}".format(first, last))

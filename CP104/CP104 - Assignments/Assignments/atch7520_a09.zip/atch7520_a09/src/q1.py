"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""

from a9_functions import sum_numbers

fv = open("text_numbers.txt", "r")
fv2 = open("output_q1.txt", "w")

fileList, sumList = sum_numbers(fv)

fv2.write(((str(fileList)).replace(", ", "+")))
    
fv2.write("={}".format(str(sumList)))

fv.close()

fv2.close()


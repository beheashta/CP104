"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""

from statistics import median


def find_median(fv):
    """
    -------------------------------------------------------
    Takes a file handle as a parameter and finds the median
    of a group of scores
    Use:  fileList,sumList = sum_numbers(fv)
    -------------------------------------------------------
    Parameters:
        fv - file handle/object
    Returns:
        scores - list of scores
        med - median of the group of scores
    -------------------------------------------------------
    """

    scores = []
    for line in fv:
        for num in line.strip().split(" "):
            scores.append(int(num))
    
    scores.sort()
    
    med = median(scores)
    
    return (scores, med)

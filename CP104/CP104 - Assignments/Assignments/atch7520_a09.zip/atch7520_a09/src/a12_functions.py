"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""


def valid_sn(txt_srl):
    
    length = len(txt_srl)
    
    if txt_srl[0:2] == "SN" and txt_srl[2] == "/" and txt_srl[3:7].isdigit() and txt_srl[7] == "-" and length == 10:
        valid = True
    
    else:
        valid = False
    
    return valid


def valid_sn_file(fv1, fv2, fv3):
    valid_cnt = 0
    
    invalid_cnt = 0

    for line in fv1:
        if valid_sn(line.strip()):
            valid_cnt += 1
            fv2.write(line.strip() + "\n")
        else:
            invalid_cnt += 1
            fv3.write(line.strip() + "\n")

    if valid_cnt == 0:
        fv2.write("None")
    elif invalid_cnt == 0: 
        fv3.write("None")
    elif valid_cnt == 0 and invalid_cnt == 0:
        fv2.write("None")
        fv3.write("None")
        

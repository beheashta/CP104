"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""

from a12_functions import valid_sn_file

fv1 = open("serial_number.txt", "r")
fv2 = open("output_valid.txt", "w")
fv3 = open("output_invalid.txt", "w")

valid_sn_file(fv1, fv2, fv3)

fv1.close()
fv2.close()
fv3.close()

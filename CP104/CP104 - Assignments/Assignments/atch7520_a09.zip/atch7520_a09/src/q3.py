"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""

from a11_functions import analysis_file

file_in = open("text.txt", "r")

fv2 = open("output_q3.txt", "w")

upper, lower, digits, white = analysis_file(file_in)

fv2.write("{},{},{},{}".format(upper, lower, digits, white))

fv2.close()
file_in.close()

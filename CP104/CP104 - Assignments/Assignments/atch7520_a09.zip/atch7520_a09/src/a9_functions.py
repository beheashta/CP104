"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""


def sum_numbers(fv):
    """
    -------------------------------------------------------
    Takes a file handle/object as a parameter and reads 
    through this text file and returns a list of the numbers
    encountered and their sum
    
    Use:  fileList,sumList = sum_numbers(fv)
    -------------------------------------------------------
    Parameters:
        fv - file handle/object
    Returns:
        fileList - list of all numbers encountered in the file
        sumList - the sum of all numbers encountered in the file
    -------------------------------------------------------
    """
    fileList = []
    line = fv.readline().split(" ")
    
    for x in line:
        if x.isdigit() == True:
            fileList.append(int(x))
    
    sumList = sum(fileList) 
    
    return(fileList, sumList)  
        

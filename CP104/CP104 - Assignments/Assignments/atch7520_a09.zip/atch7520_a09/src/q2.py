"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""

from a10_functions import find_median

fv = open("numbers.txt", "r")
fv2 = open("output_q2", "w")

scores, med = find_median(fv)

fv2.write(((str(scores)).replace(", ", "+")))
fv2.write("={}".format(med))

fv2.close()
fv.close()

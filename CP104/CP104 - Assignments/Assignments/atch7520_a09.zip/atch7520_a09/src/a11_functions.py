"""
------------------------------------------------------------------------
[program description]
------------------------------------------------------------------------
Author: Beheashta Atchekzai
ID:     190637520
Email:  atch7520@mylaurier.ca
__updated__ = "2019-11-23"
------------------------------------------------------------------------
"""


def analysis_file(file_in):
    """
    -------------------------------------------------------
    Takes a file handle as a parameter and number of attributes
    Use:  fileList,sumList = sum_numbers(fv)
    -------------------------------------------------------
    Parameters:
        file_in - file handle/object
    Returns:
        upper - # of uppercase 
        lower - # of lowercase
        digits - # of digits
        white - # of white spaces
    -------------------------------------------------------
    """
    
    digits = 0
    lower = 0 
    upper = 0
    white = 0 
    
    for lines in file_in:
        for char in lines:
            if char.isdigit():
                digits += 1
            if char.isupper():
                upper += 1   
            if char.islower():
                lower += 1   
            if char.isspace():
                white += 1 
    
    return upper, lower, digits, white
        
